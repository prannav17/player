package com.example.FootballPLayer.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.*;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Player {

    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;


    private String name;

//    @Min(value=10000, message="Please pay more than 1K")
//    @Max(value=50000, message="Paying extra")
    private int prizeMoney;


    private String team;



}
