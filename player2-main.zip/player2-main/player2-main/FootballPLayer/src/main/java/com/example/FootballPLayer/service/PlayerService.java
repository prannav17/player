package com.example.FootballPLayer.service;


import com.example.FootballPLayer.entity.Player;
import org.springframework.http.ResponseEntity;

import java.util.List;


public interface PlayerService {

    public Player savePlayer(Player player);
    public List<Player> getAllPlayers();
    public Player getPlayerById(int id);
    public ResponseEntity<String> updatePlayer(Player player);
    public ResponseEntity<String> deletePlayer(int id);
    public Player selectPlayersEarnMoreThan(int prizeMoney);
    public List<Player> findByTeam(String teamname);
}
