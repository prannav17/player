package com.example.FootballPLayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FootballPLayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FootballPLayerApplication.class, args);
	}

}
