package com.example.FootballPLayer.repository;


import com.example.FootballPLayer.entity.Player;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import jakarta.transaction.Transactional;

import java.util.List;

@Repository
public interface PlayerRepository extends JpaRepository<Player, Integer> {


    @Modifying
    @Transactional
    @Query(value = "SELECT * FROM players WHERE prizeMoney > ?1", nativeQuery = true)
    public Player selectPlayersEarnMoreThan(int prizeMoney);

    public List<Player> findByTeam(String teamname);

}
