package com.example.FootballPLayer.service;

import com.example.FootballPLayer.entity.Player;
import com.example.FootballPLayer.exception.CustomerNotFoundException;
import com.example.FootballPLayer.repository.PlayerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlayerServiceImp implements PlayerService {

    @Autowired
    PlayerRepository playerRepository;


    @Override
    public Player savePlayer(Player player) {
        return playerRepository.save(player);
    }

    @Override
    public List<Player> getAllPlayers() {
        return playerRepository.findAll();
    }

    @Override
    public Player getPlayerById(int id) {
        return playerRepository.findById(id).orElseThrow(()->new CustomerNotFoundException("No customer available"));
    }

    @Override
    public ResponseEntity<String> updatePlayer(Player player) {
        playerRepository.save(player);
        return new ResponseEntity<String>("Player Data Updated...", HttpStatus.ACCEPTED);
    }


    @Override
    public ResponseEntity<String> deletePlayer(int id) {
        playerRepository.deleteById(id);
        return new ResponseEntity<String>("Player Data Deleted...", HttpStatus.ACCEPTED);
    }

    @Override
    public Player selectPlayersEarnMoreThan(int prizeMoney) {
        return playerRepository.selectPlayersEarnMoreThan(prizeMoney);
    }

    @Override
    public List<Player> findByTeam(String teamname) {
        return playerRepository.findByTeam(teamname);
    }

}
