package com.example.FootballPLayer.controller;


import com.example.FootballPLayer.entity.Player;
import com.example.FootballPLayer.service.PlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/player")
public class PlayerController {

    @Autowired
    PlayerService service;

    @PostMapping("/add")
    public Player savePlayer(@RequestBody Player player){
        return service.savePlayer(player);
    }

    @GetMapping("/getAll")
    public List<Player> getAllPlayers(){
        return service.getAllPlayers();
    }

    @GetMapping("/getById/{id}")
    public Player getPlayerById(@PathVariable int id){
        return service.getPlayerById(id);
    }

    @PutMapping("/update")
    public ResponseEntity<String> updatePlayer(@RequestBody Player player){
        return service.updatePlayer(player);
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deletePlayer(@PathVariable int id){
        return service.deletePlayer(id);
    }

    @GetMapping("/selectPlayersEarnMoreThan/{prizeMoney}")
    public Player deletePlayersOlderThan(int prizeMoney){
        return service.selectPlayersEarnMoreThan(prizeMoney);
    }

    @GetMapping("/findByTeam/{teamname}")
    public List<Player> findByTeam(@PathVariable String teamname){
        return service.findByTeam(teamname);
    }
}
