package com.example.FootballPLayer.service;


import com.example.FootballPLayer.entity.UserInfo;
import com.example.FootballPLayer.repository.UserInfoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

@Service
public class UserInfoUserDetailsService implements UserDetailsService {

    @Autowired
    private UserInfoRepository repository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        UserInfo userInfo = repository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        String[] rolesArray = userInfo.getRoles().split(",");

        return User.builder()
                .username(userInfo.getUsername())
                .password(userInfo.getPassword())
                .authorities(rolesArray)
                .build();
    }
}

