package com.example.FootballPLayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballPLayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
